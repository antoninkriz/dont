Prevent window/tab change detection using prototype hacking and events propagation blocking.
